<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'kWskl5oA61c1Wnbj7FwKljlPd');
    define('CONSUMER_SECRET', 'kHWFARQGOcgHmCsMcd0jWBOR1zHgfTckMVJxReAn1C7CLdCz2O');

    // User Access Token
    define('ACCESS_TOKEN', '742657569492062209-XcprInlSGLU5PLuPjFnJtyYoURCxGFB');
    define('ACCESS_SECRET', 'X2LsnZJCBiMwC43zZsSVIc2YNAX1JCnBAynMWIQFRQYu9');
    
    // Cache Settings
    define('CACHE_ENABLED', false);
    define('CACHE_LIFETIME', 3600); // in seconds
    define('HASH_SALT', md5(dirname(__FILE__)));