package com.shoppingmall.common;

public class RedisKeyUtils {

    public static final String CATEGORY_LIST_KEY = "categoryList";
    public static final String BEST10_PRODUCT_LIST_KEY = "best10ProductList";
    public static final String NEW8_PRODUCT_LIST_KEY = "new8ProductList";

}
